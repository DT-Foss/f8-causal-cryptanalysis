#!/usr/bin/env python3
"""Temporal strategies from CASI V2 (Phase 5, CF516-CF519).

These treat the cipher byte stream as a TIME SERIES and detect sequential
structure via permutation Z-score normalization. They are the ONLY strategies
that use permutation normalization — the 12 byte-level strategies use
analytical Z-scores.

CF516 showed: all 8 broken ciphers (R1) detected via adj_corr_Z.
CF517 showed: the SIGN of adj_corr_Z differentiates cipher architectures.
"""

import numpy as np


DEFAULT_NPERM = 200


def _adj_corr_raw(x):
    """Signed lag-1 autocorrelation of byte stream."""
    x = np.asarray(x, dtype=float)
    mu = np.mean(x)
    sd = np.std(x)
    if sd < 1e-12:
        return 0.0
    x_std = (x - mu) / sd
    return float(np.mean(x_std[:-1] * x_std[1:]))


def _trend_raw(x):
    """Signed Pearson correlation with position index."""
    x = np.asarray(x, dtype=float)
    t = np.linspace(-1, 1, len(x))
    return float(np.corrcoef(t, x)[0, 1])


def _variance_shift_raw(x):
    """Signed quartile variance shift: growing vs shrinking variance."""
    x = np.asarray(x, dtype=float)
    n = len(x)
    q1_sd = np.std(x[:n // 4])
    q4_sd = np.std(x[3 * n // 4:])
    denom = (q1_sd + q4_sd) / 2 + 1e-12
    return float((q4_sd - q1_sd) / denom)


def _permutation_z(x, raw_func, n_perm, rng):
    """Compute permutation Z-score: (obs - mean(perm)) / sd(perm)."""
    obs = raw_func(x)
    perm_vals = np.empty(n_perm)
    for i in range(n_perm):
        perm_vals[i] = raw_func(rng.permutation(x))
    mu = np.mean(perm_vals)
    sd = np.std(perm_vals)
    if sd < 1e-12:
        return 0.0
    return float((obs - mu) / sd)


def strategy_temporal_adj_corr(keys, n_perm=DEFAULT_NPERM, rng=None):
    """Signed temporal lag-1 autocorrelation Z-score.

    Treats the cipher byte stream as a time series. Under null (random bytes),
    lag-1 autocorrelation ≈ 0 → Z ≈ 0.

    Positive = persistent byte patterns (smooth, SPN ciphers at R1)
    Negative = alternating byte patterns (choppy, Feistel ciphers at R1)

    CF516: dominant axis for ALL 8 broken ciphers.
    CF517: sign differentiates cipher architectures.
    """
    if rng is None:
        rng = np.random.default_rng()
    stream = keys.ravel().astype(float)
    # Use up to 10000 bytes for speed
    if len(stream) > 10000:
        stream = stream[:10000]
    return _permutation_z(stream, _adj_corr_raw, n_perm, rng)


def strategy_temporal_trend(keys, n_perm=DEFAULT_NPERM, rng=None):
    """Signed temporal trend Z-score.

    Pearson correlation between byte values and their position index.
    Positive = bytes tend to increase over the stream.
    Negative = bytes tend to decrease.
    """
    if rng is None:
        rng = np.random.default_rng()
    stream = keys.ravel().astype(float)
    if len(stream) > 10000:
        stream = stream[:10000]
    return _permutation_z(stream, _trend_raw, n_perm, rng)


def strategy_temporal_variance(keys, n_perm=DEFAULT_NPERM, rng=None):
    """Signed temporal variance shift Z-score.

    Compares standard deviation of first quarter vs last quarter of stream.
    Positive = variance grows over time.
    Negative = variance shrinks.
    """
    if rng is None:
        rng = np.random.default_rng()
    stream = keys.ravel().astype(float)
    if len(stream) > 10000:
        stream = stream[:10000]
    return _permutation_z(stream, _variance_shift_raw, n_perm, rng)


TEMPORAL_STRATEGIES = {
    'temporal_adj_corr': strategy_temporal_adj_corr,
    'temporal_trend': strategy_temporal_trend,
    'temporal_variance': strategy_temporal_variance,
}

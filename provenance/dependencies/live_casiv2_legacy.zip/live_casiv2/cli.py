#!/usr/bin/env python3
"""live-casiv2 CLI: signed Z-score cryptographic analysis.

Modes:
  test       Run all 8 ciphers × test rounds (quick validation)
  demo       Progressive round demonstration for a cipher
  identify   Blind cipher identification from raw bytes
  scan       Analyze raw byte file or stdin
  profile    Show full 15-axis signed Z-score profile
  benchmark  Full frontier sweep for all ciphers
"""

import argparse
import sys
import time
import numpy as np

from .engine import (
    compute_profile, compute_casi, compute_casi_with_ci,
    interpret, dominant_axis, casi_verdict, casi_color,
    STRATEGY_NAMES, CRYPTO_STRATEGY_NAMES, IMPL_STRATEGY_NAMES,
    TEMPORAL_STRATEGY_NAMES, N_STRATEGIES, EFFECTIVE_DF,
    LiveCASIv2,
)
from .ciphers import CIPHERS


def cmd_test(args):
    """Run all 8 ciphers × test rounds."""
    n_keys = args.n_keys
    rng = np.random.default_rng(args.seed)

    print(f"live-casiv2 test — {len(CIPHERS)} ciphers, N={n_keys}")
    print(f"{'Cipher':15s} {'Rounds':>7s} {'||Z||':>8s} {'Verdict':>10s} "
          f"{'Dominant axis':>22s} {'Z':>10s} {'Time':>6s}")
    print("-" * 85)

    for cipher_name, info in CIPHERS.items():
        for r in info['test_rounds']:
            t0 = time.time()
            n = min(n_keys, 500) if info.get('slow') else n_keys
            raw = info['generator'](n, rounds=r, seed=args.seed)
            keys = np.frombuffer(raw, dtype=np.uint8).reshape(-1, 32)
            profile = compute_profile(keys, rng=rng)
            casi = float(np.sqrt(np.sum(profile ** 2)))
            verdict = casi_verdict(casi, n)
            dom_name, dom_z, _ = dominant_axis(profile)
            dt = time.time() - t0

            color = casi_color(casi)
            reset = '\033[0m'
            print(f"{info['name']:15s} R{r:<5d} {color}{casi:8.2f}{reset} "
                  f"{verdict:>10s} {dom_name:>22s} {dom_z:+10.2f} {dt:5.2f}s")


def cmd_demo(args):
    """Progressive round demonstration."""
    cipher_name = args.cipher.lower()
    if cipher_name not in CIPHERS:
        print(f"Unknown cipher: {args.cipher}")
        print(f"Available: {', '.join(CIPHERS.keys())}")
        sys.exit(1)

    info = CIPHERS[cipher_name]
    n_keys = args.n_keys
    rng = np.random.default_rng(args.seed)

    print(f"\nlive-casiv2 demo — {info['name']} ({info['family']})")
    print(f"Full rounds: {info['full_rounds']}, V1 frontier: R{info['frontier']}")
    print()

    for r, desc in info['demo_sequence']:
        n = min(n_keys, 500) if info.get('slow') else n_keys
        raw = info['generator'](n, rounds=r, seed=args.seed)
        keys = np.frombuffer(raw, dtype=np.uint8).reshape(-1, 32)
        profile = compute_profile(keys, rng=rng)
        result = interpret(profile)

        color = casi_color(result['composite'])
        reset = '\033[0m'
        print(f"  {desc}")
        print(f"    {color}||Z|| = {result['composite']:.2f} — {result['verdict']}{reset}")
        dom = result['dominant']
        print(f"    Dominant: {dom['name']} Z={dom['z']:+.2f}")
        if result['direction']:
            print(f"    Direction: {result['direction']}")
        print()


def cmd_scan(args):
    """Analyze raw bytes from file or stdin."""
    if args.file == '-':
        data = sys.stdin.buffer.read()
    else:
        with open(args.file, 'rb') as f:
            data = f.read()

    if len(data) < 32:
        print(f"Error: need at least 32 bytes, got {len(data)}")
        sys.exit(1)

    key_size = args.key_size
    n_keys = len(data) // key_size
    keys = np.frombuffer(data[:n_keys * key_size], dtype=np.uint8).reshape(-1, key_size)

    rng = np.random.default_rng(args.seed)
    print(f"\nlive-casiv2 scan — {len(data)} bytes, {n_keys} blocks of {key_size}")

    if args.ci:
        result = compute_casi_with_ci(keys, n_bootstrap=args.bootstrap, rng=rng)
        print(f"\n  ||Z|| = {result['point_estimate']:.2f}")
        print(f"  95% CI: [{result['ci_lower']:.2f}, {result['ci_upper']:.2f}]")
        print(f"  Bootstrap: mean={result['mean']:.2f}, std={result['std']:.3f}")
        verdict = casi_verdict(result['point_estimate'], n_keys)
    else:
        profile = compute_profile(keys, rng=rng)
        result = interpret(profile)
        verdict = result['verdict']
        casi = result['composite']

        color = casi_color(casi)
        reset = '\033[0m'
        print(f"\n  {color}||Z|| = {casi:.2f} — {verdict}{reset}")
        print(f"  Dominant: {result['dominant']['name']} Z={result['dominant']['z']:+.2f}")
        if result['direction']:
            print(f"  Direction: {result['direction']}")

    if args.verbose:
        profile = compute_profile(keys, rng=rng)
        print(f"\n  Full profile ({N_STRATEGIES} axes):")
        for i, name in enumerate(STRATEGY_NAMES):
            z = float(profile[i])
            sig = "*" if abs(z) > 2.0 else " "
            bar_len = min(int(abs(z)), 40)
            bar = ("+" * bar_len if z > 0 else "-" * bar_len)
            print(f"    {name:25s} {z:+8.2f} {sig} {bar}")


def cmd_profile(args):
    """Show full 15-axis signed Z-score profile."""
    cipher_name = args.cipher.lower()
    if cipher_name not in CIPHERS:
        print(f"Unknown cipher: {args.cipher}")
        sys.exit(1)

    info = CIPHERS[cipher_name]
    rounds = args.rounds or info['test_rounds'][0]
    n_keys = args.n_keys
    rng = np.random.default_rng(args.seed)

    n = min(n_keys, 500) if info.get('slow') else n_keys
    raw = info['generator'](n, rounds=rounds, seed=args.seed)
    keys = np.frombuffer(raw, dtype=np.uint8).reshape(-1, 32)
    profile = compute_profile(keys, rng=rng)
    result = interpret(profile)

    print(f"\nlive-casiv2 profile — {info['name']} R{rounds}")
    print(f"||Z|| = {result['composite']:.2f} — {result['verdict']}")
    print(f"\n{'Strategy':25s} {'Z-score':>10s} {'Sig':>4s} {'Direction'}")
    print("-" * 60)

    for i, name in enumerate(STRATEGY_NAMES):
        z = float(profile[i])
        sig = " **" if abs(z) > 2.0 else ""
        d = result['axes'][name]['direction']
        print(f"{name:25s} {z:+10.2f} {sig:>4s} {d}")

    print(f"\nDominant: {result['dominant']['name']} Z={result['dominant']['z']:+.2f}")
    if result['direction']:
        print(f"Direction: {result['direction']}")


def cmd_identify(args):
    """Blind cipher identification from raw bytes."""
    if args.file == '-':
        data = sys.stdin.buffer.read()
    else:
        with open(args.file, 'rb') as f:
            data = f.read()

    key_size = args.key_size
    n_keys = len(data) // key_size
    if n_keys < 100:
        print(f"Error: need at least 100 blocks, got {n_keys}")
        sys.exit(1)

    keys = np.frombuffer(data[:n_keys * key_size], dtype=np.uint8).reshape(-1, key_size)
    rng = np.random.default_rng(args.seed)
    unknown = compute_profile(keys, rng=rng)

    # Build reference profiles
    ref_n = min(args.n_keys, 500)
    references = {}
    for cipher_name, info in CIPHERS.items():
        r1 = info['test_rounds'][0]
        n = min(ref_n, 500) if info.get('slow') else ref_n
        raw = info['generator'](n, rounds=r1, seed=args.seed)
        ref_keys = np.frombuffer(raw, dtype=np.uint8).reshape(-1, 32)
        references[cipher_name] = compute_profile(ref_keys, rng=rng)

    # Cosine similarity
    def cosine(a, b):
        na, nb = np.linalg.norm(a), np.linalg.norm(b)
        if na < 1e-12 or nb < 1e-12:
            return 0.0
        return float(np.dot(a, b) / (na * nb))

    print(f"\nlive-casiv2 identify — {n_keys} blocks")
    print(f"\n{'Cipher':15s} {'Cosine':>8s}")
    print("-" * 25)

    results = []
    for name, ref in references.items():
        sim = cosine(unknown, ref)
        results.append((name, sim))
        print(f"{CIPHERS[name]['name']:15s} {sim:+.4f}")

    best = max(results, key=lambda x: x[1])
    print(f"\nBest match: {CIPHERS[best[0]]['name']} (cosine={best[1]:.4f})")


def cmd_pipe(args):
    """Streaming analysis from stdin."""
    engine = LiveCASIv2(
        key_size=args.key_size,
        window_keys=args.window,
        update_every=args.update,
    )

    print(f"live-casiv2 pipe — streaming analysis (window={args.window}, "
          f"update_every={args.update})")

    try:
        while True:
            chunk = sys.stdin.buffer.read(args.chunk)
            if not chunk:
                break
            updated = engine.feed(chunk)
            if updated and engine.current_casi is not None:
                color = casi_color(engine.current_casi)
                reset = '\033[0m'
                verdict = casi_verdict(engine.current_casi, engine.keys_total)
                rate = engine.rate()
                print(f"  [{engine.elapsed():6.1f}s] {color}||Z||={engine.current_casi:.2f}{reset} "
                      f"{verdict:10s} keys={engine.keys_total:,d} rate={rate:.0f}/s")
    except KeyboardInterrupt:
        pass

    # Final update
    engine.force_update()
    if engine.current_casi is not None:
        print(f"\n  Final: ||Z||={engine.current_casi:.2f} "
              f"({casi_verdict(engine.current_casi, engine.keys_total)}) "
              f"keys={engine.keys_total:,d}")


def main():
    parser = argparse.ArgumentParser(
        prog='live-casiv2',
        description='Signed Z-score cryptographic quality analysis',
    )
    parser.add_argument('--version', action='version', version='live-casiv2 2.0.0')

    sub = parser.add_subparsers(dest='command')

    # test
    p_test = sub.add_parser('test', help='Run cipher validation suite')
    p_test.add_argument('-n', '--n-keys', type=int, default=5000)
    p_test.add_argument('--seed', type=int, default=42)

    # demo
    p_demo = sub.add_parser('demo', help='Progressive round demonstration')
    p_demo.add_argument('cipher', help='Cipher name (chacha, aes, speck, ...)')
    p_demo.add_argument('-n', '--n-keys', type=int, default=5000)
    p_demo.add_argument('--seed', type=int, default=42)

    # scan
    p_scan = sub.add_parser('scan', help='Analyze raw byte file')
    p_scan.add_argument('file', help='File path or - for stdin')
    p_scan.add_argument('-k', '--key-size', type=int, default=32)
    p_scan.add_argument('-v', '--verbose', action='store_true')
    p_scan.add_argument('--ci', action='store_true', help='Compute bootstrap CI')
    p_scan.add_argument('--bootstrap', type=int, default=100)
    p_scan.add_argument('--seed', type=int, default=42)

    # profile
    p_prof = sub.add_parser('profile', help='Full 15-axis Z-score profile')
    p_prof.add_argument('cipher', help='Cipher name')
    p_prof.add_argument('-r', '--rounds', type=int, default=None)
    p_prof.add_argument('-n', '--n-keys', type=int, default=5000)
    p_prof.add_argument('--seed', type=int, default=42)

    # identify
    p_id = sub.add_parser('identify', help='Blind cipher identification')
    p_id.add_argument('file', help='File path or - for stdin')
    p_id.add_argument('-k', '--key-size', type=int, default=32)
    p_id.add_argument('-n', '--n-keys', type=int, default=5000)
    p_id.add_argument('--seed', type=int, default=42)

    # pipe
    p_pipe = sub.add_parser('pipe', help='Streaming analysis from stdin')
    p_pipe.add_argument('-k', '--key-size', type=int, default=32)
    p_pipe.add_argument('-w', '--window', type=int, default=10000)
    p_pipe.add_argument('-u', '--update', type=int, default=1000)
    p_pipe.add_argument('-c', '--chunk', type=int, default=8192)

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    cmds = {
        'test': cmd_test,
        'demo': cmd_demo,
        'scan': cmd_scan,
        'profile': cmd_profile,
        'identify': cmd_identify,
        'pipe': cmd_pipe,
    }
    cmds[args.command](args)


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""V2 strategies: each returns a SIGNED FLOAT Z-score, not an unsigned count.

Architecture change from V1:
- V1: each strategy counts how many sub-tests exceed abs(Z) > 3.5 → unsigned integer
- V2: each strategy computes a SINGLE signed Z-score → signed float

The sign carries information:
- bit_correlation > 0: MORE correlated than random (bias toward same bits)
- bit_correlation < 0: LESS correlated (anti-correlation, also a flaw)
- entropy > 0: excess entropy (shouldn't happen in practice)
- entropy < 0: deficit entropy (low-entropy PRNG)
- autocorrelation > 0: persistent byte patterns (smooth)
- autocorrelation < 0: alternating byte patterns (choppy)
- etc.

Under null (random bytes), each Z ~ N(0,1) by construction.
"""

import math
import numpy as np


# ═══════════════════════════════════════════════════════════════
# CRYPTO STRATEGIES (original 4 from IEEE paper)
# ═══════════════════════════════════════════════════════════════

def strategy_bit_correlation(keys):
    """Signed mean Z of bit-pair correlations.

    For each pair of byte positions, each bit: fraction where bits agree.
    Under null, agreement = 0.5. Positive Z = excess agreement (correlated),
    negative Z = deficit (anti-correlated).

    Returns the MEAN signed Z across all tested pairs — a single aggregate
    measure of how much bit-pair correlation deviates from random.
    """
    n_keys, key_len = keys.shape
    if n_keys < 100:
        return 0.0

    expected = 0.5
    std = math.sqrt(0.25 / n_keys)  # std of binomial proportion

    z_values = []
    positions = list(range(min(key_len, 16)))
    for i in range(len(positions)):
        for j in range(i + 1, len(positions)):
            pi, pj = positions[i], positions[j]
            for bit in range(8):
                bi = (keys[:, pi] >> bit) & 1
                bj = (keys[:, pj] >> bit) & 1
                agreement = np.mean(bi == bj)
                z = (agreement - expected) / std
                z_values.append(z)

    if not z_values:
        return 0.0
    # Mean Z across all pairs: under null, mean of N(0,1) ~ N(0, 1/sqrt(n_pairs))
    # We scale to get a single Z ~ N(0,1) under null
    mean_z = np.mean(z_values)
    return float(mean_z * math.sqrt(len(z_values)))


def strategy_xor_distribution(keys):
    """Chi-squared Z-score of XOR byte distribution.

    XOR of byte pairs should be uniform(0,255). Compute chi² statistic
    across all pair histograms, then Z-score against expected chi².

    Positive Z = more non-uniform than expected (structure in XOR).
    """
    n_keys, key_len = keys.shape
    if n_keys < 100:
        return 0.0

    expected_count = n_keys / 256.0
    chi2_values = []

    positions = list(range(min(key_len, 10)))
    for i in range(len(positions)):
        for j in range(i + 1, min(i + 3, len(positions))):
            pi, pj = positions[i], positions[j]
            hist = np.bincount(keys[:, pi] ^ keys[:, pj], minlength=256).astype(float)
            chi2 = np.sum((hist - expected_count) ** 2 / expected_count)
            chi2_values.append(chi2)

    if not chi2_values:
        return 0.0

    # Under null, each chi²(255) has mean=255, var=510.
    # Mean of n_pairs chi² values has std = sqrt(510/n_pairs).
    n_pairs = len(chi2_values)
    mean_chi2 = np.mean(chi2_values)
    expected_chi2 = 255.0
    std_of_mean = math.sqrt(510.0 / n_pairs)
    return float((mean_chi2 - expected_chi2) / std_of_mean)


def strategy_parity_chain(keys):
    """Signed parity chain correlation Z-score.

    Adjacent byte parities should be independent. Correlation > 0 means
    parity persists (same parity tends to follow same parity).
    """
    n_keys, key_len = keys.shape
    if n_keys < 100:
        return 0.0

    expected = 0.5
    std = math.sqrt(0.25 / n_keys)

    lookup = np.array([bin(i).count('1') % 2 for i in range(256)], dtype=np.uint8)
    parities = lookup[keys]

    z_values = []
    for i in range(min(key_len - 1, 16)):
        agreement = np.mean(parities[:, i] == parities[:, i + 1])
        z = (agreement - expected) / std
        z_values.append(z)

    if not z_values:
        return 0.0
    mean_z = np.mean(z_values)
    return float(mean_z * math.sqrt(len(z_values)))


def strategy_cross_bit(keys):
    """Signed cross-bit correlation Z-score.

    Bit b1 at position p should be independent of bit b2 at position p+1.
    Positive Z = excess agreement, negative = anti-correlation.
    """
    n_keys, key_len = keys.shape
    if n_keys < 100:
        return 0.0

    expected = 0.5
    std = math.sqrt(0.25 / n_keys)

    z_values = []
    for pos in range(min(key_len - 1, 8)):
        for bk in range(8):
            for bl in range(8):
                b1 = (keys[:, pos] >> bk) & 1
                b2 = (keys[:, pos + 1] >> bl) & 1
                agreement = np.mean(b1 == b2)
                z = (agreement - expected) / std
                z_values.append(z)

    if not z_values:
        return 0.0
    mean_z = np.mean(z_values)
    return float(mean_z * math.sqrt(len(z_values)))


# ═══════════════════════════════════════════════════════════════
# IMPLEMENTATION STRATEGIES (8 strategies)
# ═══════════════════════════════════════════════════════════════

def strategy_block_repetition(keys):
    """Z-score of block collision count.

    Under null, expected collisions = 0 for 16-byte blocks with 10K keys.
    Any collision is massive. Returns Z from Poisson approximation.
    Always positive (collisions can't be negative).
    """
    n_keys, key_len = keys.shape
    if n_keys < 50:
        return 0.0

    total_collisions = 0
    for block_size in [16, 8]:
        blocks_per_key = key_len // block_size
        if blocks_per_key < 1:
            continue

        n_blocks = n_keys * blocks_per_key
        all_blocks = keys[:, :blocks_per_key * block_size].reshape(n_blocks, block_size)

        if block_size == 16:
            # Full 16-byte comparison: hash both halves and combine
            h_lo = all_blocks[:, :8].copy().view(np.uint64).ravel()
            h_hi = all_blocks[:, 8:16].copy().view(np.uint64).ravel()
            # Sort by (h_lo, h_hi) — check both halves match
            order = np.lexsort((h_hi, h_lo))
            h_lo_s = h_lo[order]
            h_hi_s = h_hi[order]
            duplicates = int(np.sum((h_lo_s[1:] == h_lo_s[:-1]) & (h_hi_s[1:] == h_hi_s[:-1])))
        elif block_size >= 8:
            hashes = all_blocks[:, :8].copy().view(np.uint64).ravel()
            sorted_h = np.sort(hashes)
            duplicates = int(np.sum(sorted_h[1:] == sorted_h[:-1]))
        else:
            hashes = np.zeros(n_blocks, dtype=np.uint64)
            for b in range(block_size):
                hashes |= all_blocks[:, b].astype(np.uint64) << (8 * b)
            sorted_h = np.sort(hashes)
            duplicates = int(np.sum(sorted_h[1:] == sorted_h[:-1]))

        total_collisions += duplicates

    if total_collisions == 0:
        return 0.0
    # Z-score: Poisson(lambda≈expected_collisions). For 8-byte blocks at N=640K,
    # expected ≈ N²/(2·2^64) ≈ 0.011. Any collision is massive Z.
    # Use sqrt(collisions) scaling to preserve dynamic range across orders of magnitude.
    return float(min(math.sqrt(total_collisions) * 10.0, 100.0))


def strategy_byte_frequency(keys):
    """Chi-squared Z-score of byte frequency distribution.

    Under null, each byte value has equal probability 1/256.
    Positive Z = more non-uniform than expected.
    """
    n_keys, key_len = keys.shape
    if n_keys < 100:
        return 0.0

    flat = keys.ravel()
    n_total = len(flat)
    expected = n_total / 256.0

    hist = np.bincount(flat, minlength=256).astype(float)
    chi2 = float(np.sum((hist - expected) ** 2 / expected))

    # chi²(255) under null: mean=255, var=510
    z = (chi2 - 255.0) / math.sqrt(510.0)
    return float(z)


def strategy_seq_correlation(keys):
    """Signed sequential correlation Z-score.

    XOR consecutive keys → hamming weight. Under null, HW ~ Binomial(n_bits, 0.5).
    Positive Z = TOO MANY bit differences (anti-correlated keys).
    Negative Z = TOO FEW differences (correlated keys, nonce reuse).
    """
    n_keys, key_len = keys.shape
    if n_keys < 100:
        return 0.0

    diffs = keys[1:] ^ keys[:-1]
    popcount_lut = np.array([bin(i).count('1') for i in range(256)], dtype=np.int32)
    hw = popcount_lut[diffs].sum(axis=1).astype(float)

    expected_hw = key_len * 4.0
    std_hw = math.sqrt(key_len * 2.0)

    # Mean signed deviation
    mean_hw = np.mean(hw)
    n_diffs = len(hw)
    z = (mean_hw - expected_hw) / (std_hw / math.sqrt(n_diffs))

    # Also check for constant diff pattern (LCG) — add bonus signal
    if n_diffs >= 10:
        first_diff = diffs[0]
        matches = np.all(diffs == first_diff, axis=1)
        constant_ratio = np.sum(matches) / n_diffs
        if constant_ratio > 0.5:
            z = float(z) - 50.0  # Massive negative signal (keys TOO similar)

    return float(z)


def strategy_entropy(keys):
    """Signed Shannon entropy Z-score on flattened byte stream.

    Under null, H ≈ 8.0 bits/byte. Negative Z = low entropy (weak PRNG).
    Uses the GLOBAL byte distribution (all positions combined) for maximum
    sensitivity. Per-position entropy is too well-concentrated for useful
    Z-scores at typical sample sizes.
    """
    n_keys, key_len = keys.shape
    if n_keys < 100:
        return 0.0

    flat = keys.ravel()
    n_total = len(flat)
    hist = np.bincount(flat, minlength=256).astype(np.float64)
    probs = hist / n_total
    probs = probs[probs > 0]
    entropy = -float(np.sum(probs * np.log2(probs)))

    # Miller-Madow bias correction
    k_nonzero = np.sum(hist > 0)
    expected_h = 8.0 - (k_nonzero - 1) / (2.0 * n_total * math.log(2))

    # Entropy std scales as 1/n (NOT 1/sqrt(n)): std ≈ 17/n_total
    # This is the variance of the MLE Shannon entropy estimator for large K categories
    std_h = 17.0 / n_total

    if std_h < 1e-15:
        return 0.0
    z = (entropy - expected_h) / std_h  # SIGNED — negative = low entropy
    return float(z)


def strategy_runs(keys):
    """Signed run-length Z-score.

    Under null, runs ≈ (n_bits + 1) / 2. Positive Z = TOO MANY runs
    (rapid alternation). Negative Z = TOO FEW runs (long same-bit stretches).
    """
    n_keys, key_len = keys.shape
    if n_keys < 100:
        return 0.0

    test_len = min(key_len, 8)
    bits = np.unpackbits(keys[:, :test_len], axis=1)
    n_bits = bits.shape[1]

    transitions = np.sum(bits[:, 1:] != bits[:, :-1], axis=1)
    runs_count = transitions.astype(float) + 1.0

    expected_runs = (n_bits + 1) / 2.0
    std_runs = math.sqrt((n_bits - 1) / 4.0)

    # Mean signed Z across all keys
    z_per_key = (runs_count - expected_runs) / std_runs
    mean_z = np.mean(z_per_key)
    return float(mean_z * math.sqrt(n_keys))


def strategy_spectral(keys):
    """Spectral peak Z-score via FFT periodogram.

    Under null, normalized periodogram values ~ Exp(1). We compute the
    mean max-peak across byte positions and Z-score against empirical null.
    Positive Z = unexplained periodicity.
    """
    n_keys, key_len = keys.shape
    if n_keys < 256:
        return 0.0

    n = min(n_keys, 4096)
    positions = min(key_len, 16)
    max_peaks = []

    for pos in range(positions):
        signal = keys[:n, pos].astype(np.float64) - 127.5
        var = np.var(signal)
        if var < 1e-10:
            max_peaks.append(1000.0)  # constant = catastrophic
            continue

        power = np.abs(np.fft.rfft(signal)[1:]) ** 2
        normalized = power / (n * var / 2.0)
        max_peaks.append(float(np.max(normalized)))

    if not max_peaks:
        return 0.0

    mean_peak = np.mean(max_peaks)

    # Size-adaptive null calibration for mean-of-max-peaks.
    # Calibrated across N=500-10000: mean_peak ≈ 2·ln(n_bins) + 1.25, std ≈ 0.65
    n_bins = n // 2
    null_mean = 2.0 * math.log(max(n_bins, 2)) + 1.25
    null_std = 0.65
    z = (mean_peak - null_mean) / null_std
    return float(z)


def strategy_compression(keys):
    """Compressibility detection via zlib.

    Random data is incompressible (ratio ≈ 1.0). Structured data compresses.
    Returns 0 if data looks random, positive Z proportional to compressibility.

    This strategy is inherently one-sided (structure only compresses, never
    expands beyond random). Under null, returns ~0. Under signal, returns
    large positive values proportional to compression reduction %.
    """
    import zlib
    n_keys, key_len = keys.shape
    if n_keys < 100:
        return 0.0

    raw = keys.tobytes()
    raw_len = len(raw)
    compressed_len = len(zlib.compress(raw, level=1))

    ratio = compressed_len / raw_len

    # Random data at 160KB: ratio ≈ 1.0003 (zlib overhead).
    # Any ratio < 0.999 indicates structure.
    # Scale: 1% compression = Z≈5, 5% = Z≈25, 50% = Z≈250
    if ratio > 0.999:
        return 0.0

    reduction_pct = (1.0 - ratio) * 100.0
    return float(reduction_pct * 5.0)


def strategy_byte_skewness(keys):
    """Signed skewness Z-score of the flattened byte distribution.

    3rd standardized central moment. For Uniform(0,255): γ₁ = 0 (symmetric).
    Positive Z = right-skewed bytes, negative = left-skewed.
    Catches: SPN ciphers with weak S-boxes produce asymmetric byte distributions.

    Uses empirically calibrated null std (ref N=5000×32=160000 bytes).
    """
    n_keys, key_len = keys.shape
    if n_keys < 100:
        return 0.0

    flat = keys.ravel().astype(np.float64)
    n = len(flat)
    x_bar = np.mean(flat)
    m2 = np.mean((flat - x_bar) ** 2)
    m3 = np.mean((flat - x_bar) ** 3)

    if m2 < 1e-10:
        return 0.0

    g1 = m3 / (m2 ** 1.5)  # sample skewness

    # Empirically calibrated: at N=160000, std(g1) ≈ 0.003677
    # Scales as 1/sqrt(n)
    ref_std = 0.003677
    ref_n = 160000
    null_std = ref_std * math.sqrt(ref_n / n)
    if null_std < 1e-15:
        return 0.0

    z = g1 / null_std
    return float(z)


def strategy_byte_kurtosis(keys):
    """Signed excess kurtosis Z-score of the flattened byte distribution.

    For Uniform(0,255): excess kurtosis κ = -6/5 = -1.2 (platykurtic).
    Positive Z = heavy-tailed (extreme byte values), negative = too flat.
    Catches: block cipher key scheduling errors, DES weak keys.

    Uses empirically calibrated null parameters (ref N=5000×32=160000 bytes).
    """
    n_keys, key_len = keys.shape
    if n_keys < 100:
        return 0.0

    flat = keys.ravel().astype(np.float64)
    n = len(flat)
    x_bar = np.mean(flat)
    m2 = np.mean((flat - x_bar) ** 2)
    m4 = np.mean((flat - x_bar) ** 4)

    if m2 < 1e-10:
        return 0.0

    kappa = m4 / (m2 ** 2) - 3.0  # excess kurtosis
    expected_kappa = -1.2  # Uniform(0,255) exact value

    # Empirically calibrated: at N=160000, std(kappa) ≈ 0.003002
    # Scales as 1/sqrt(n)
    ref_std = 0.003002
    ref_n = 160000
    null_std = ref_std * math.sqrt(ref_n / n)
    if null_std < 1e-15:
        return 0.0

    z = (kappa - expected_kappa) / null_std
    return float(z)


def strategy_autocorrelation(keys):
    """SIGNED byte-level autocorrelation Z-score.

    V1 used abs(autocorr). V2 keeps the SIGN:
    Positive = persistent byte patterns (smooth, like SPN R1)
    Negative = alternating byte patterns (choppy, like Feistel R1)

    Uses lag-1 only (the strongest signal for reduced-round ciphers, CF516).
    Multi-lag detection is handled by the temporal strategies.
    """
    n_keys, key_len = keys.shape
    if n_keys < 200:
        return 0.0

    stream = keys.ravel().astype(np.float64) - 127.5
    n = len(stream)
    var = np.var(stream)
    if var < 1e-10:
        return 100.0  # constant stream

    # Lag-1 autocorrelation only — clean N(0,1) under null
    autocorr = np.mean(stream[:n - 1] * stream[1:]) / var
    std_ac = 1.0 / math.sqrt(n - 1)
    z = autocorr / std_ac  # SIGNED — no abs()!

    return float(z)


def _berlekamp_massey(bits):
    """Berlekamp-Massey algorithm for linear complexity over GF(2)."""
    n = len(bits)
    c = np.zeros(n + 1, dtype=np.uint8)
    c[0] = 1
    b = np.zeros(n + 1, dtype=np.uint8)
    b[0] = 1
    L = 0
    m = -1
    for N in range(n):
        d = bits[N]
        for i in range(1, L + 1):
            d ^= c[i] & bits[N - i]
        if d:
            t = c.copy()
            shift = N - m
            for i in range(shift, n + 1):
                c[i] ^= b[i - shift]
            if L <= N // 2:
                L = N + 1 - L
                m = N
                b = t
    return L


def strategy_linear_complexity(keys):
    """Linear complexity Z-score via Berlekamp-Massey — covers NIST Test 10.

    Measures how close to LFSR-producible the output is.
    For n random bits: E[L] = n/2 + (4+(-1)^n)/18 + 2/9.
    Negative Z = below-expected complexity = LFSR-like structure.

    Uses blocks of 500 bits, aggregates across blocks.
    Empirically calibrated null std.
    """
    n_keys, key_len = keys.shape
    if n_keys < 100:
        return 0.0

    bits = np.unpackbits(keys.ravel())
    block_size = 500
    n_blocks = min(len(bits) // block_size, 100)
    if n_blocks < 5:
        return 0.0

    # Expected linear complexity for random bits of length n
    n = block_size
    expected_L = n / 2.0 + (4 + (-1) ** n) / 18.0 + 2.0 / 9.0

    deviations = []
    for i in range(n_blocks):
        block = bits[i * block_size:(i + 1) * block_size]
        L = _berlekamp_massey(block)
        deviations.append(L - expected_L)

    deviations = np.array(deviations, dtype=np.float64)
    mean_dev = np.mean(deviations)

    # Empirically calibrated at N=5000 (100 blocks of 500 bits):
    # mean_dev null: -0.279, std of mean_dev: 0.106, block_std: 1.062
    ref_block_mean = -0.279
    ref_block_std = 1.062
    null_std = ref_block_std / math.sqrt(n_blocks)
    if null_std < 1e-15:
        return 0.0

    z = (mean_dev - ref_block_mean) / null_std
    return float(z)


def strategy_matrix_rank(keys):
    """Binary matrix rank Z-score — covers NIST SP 800-22 Test 5.

    Catches LINEAR DEPENDENCIES invisible to all frequency-based tests.
    Unpacks to bits, reshapes into 32x32 binary matrices over GF(2).
    Expected rank distribution: P(32)=0.2888, P(31)=0.5776, P(≤30)=0.1336.
    Chi²(2) → Z-score.
    Positive Z = rank deficit = linear dependence in output.
    """
    n_keys, key_len = keys.shape
    if n_keys < 100:
        return 0.0

    bits = np.unpackbits(keys, axis=1)  # (n_keys, key_len*8)
    n_bits_per_key = bits.shape[1]
    mat_size = 32
    bits_needed = mat_size * mat_size  # 1024

    if n_bits_per_key * n_keys < bits_needed * 10:
        return 0.0

    # Reshape into 32x32 matrices
    flat_bits = bits.ravel()
    n_matrices = len(flat_bits) // bits_needed
    n_matrices = min(n_matrices, 200)  # cap for speed
    if n_matrices < 10:
        return 0.0

    matrices = flat_bits[:n_matrices * bits_needed].reshape(n_matrices, mat_size, mat_size)

    # GF(2) rank for each matrix
    rank_counts = {32: 0, 31: 0, 'le30': 0}
    for mi in range(n_matrices):
        m = matrices[mi].copy().astype(np.uint8)
        rank = 0
        for col in range(mat_size):
            pivot = None
            for row in range(rank, mat_size):
                if m[row, col]:
                    pivot = row
                    break
            if pivot is None:
                continue
            m[[rank, pivot]] = m[[pivot, rank]]
            for row in range(mat_size):
                if row != rank and m[row, col]:
                    m[row] ^= m[rank]
            rank += 1

        if rank == 32:
            rank_counts[32] += 1
        elif rank == 31:
            rank_counts[31] += 1
        else:
            rank_counts['le30'] += 1

    # Expected proportions
    p_32 = 0.2888
    p_31 = 0.5776
    p_le30 = 0.1336

    expected = np.array([p_32, p_31, p_le30]) * n_matrices
    observed = np.array([rank_counts[32], rank_counts[31], rank_counts['le30']], dtype=float)

    # Avoid division by zero
    mask = expected > 0
    if not np.any(mask):
        return 0.0

    chi2 = float(np.sum((observed[mask] - expected[mask]) ** 2 / expected[mask]))

    # chi²(2) → Z: mean=2, std=2
    z = (chi2 - 2.0) / 2.0
    return float(z)


def strategy_approx_entropy(keys):
    """Approximate entropy (ApEn) Z-score — covers NIST SP 800-22 Test 12.

    ApEn = φ^m - φ^(m+1) where φ^m = Σ(c_j/n)·log(c_j/n).
    Under null: ApEn ≈ ln(2) ≈ 0.6931 for m=2.
    Negative Z = too regular (deterministic structure in bit patterns).

    Uses m=2, first 10000 bits from byte stream.
    Empirically calibrated (ref N=10000 bits, mean=0.69295, std=0.000157).
    """
    n_keys, key_len = keys.shape
    if n_keys < 100:
        return 0.0

    flat = keys.ravel()
    bits = np.unpackbits(flat)
    n_bits = min(len(bits), 10000)
    bits = bits[:n_bits]
    n = n_bits
    m = 2

    phi = [0.0, 0.0]
    for idx, mm in enumerate([m, m + 1]):
        counts = {}
        for i in range(n - mm + 1):
            p = 0
            for b in range(mm):
                p = (p << 1) | int(bits[i + b])
            counts[p] = counts.get(p, 0) + 1
        total = n - mm + 1
        if total <= 0:
            return 0.0
        phi[idx] = sum((c / total) * np.log(c / total) for c in counts.values())

    apen = phi[0] - phi[1]

    # Empirically calibrated: at 10000 bits, mean=0.69295, std=0.000157
    # Scale: std ∝ 1/sqrt(n_bits/10000)
    ref_mean = 0.69295
    ref_std = 0.000157
    ref_n = 10000
    null_std = ref_std * math.sqrt(ref_n / n_bits)
    if null_std < 1e-15:
        return 0.0

    z = (apen - ref_mean) / null_std
    return float(z)


def strategy_mutual_information(keys):
    """Mutual information Z-score between adjacent byte positions.

    MI captures ALL forms of dependence (not just linear/XOR).
    Uses 16-bin histograms (top 4 bits) for stable chi² statistics.
    G-test: 2*n*MI*ln(2) ~ χ²(225) under independence.
    Positive Z = byte positions are dependent.

    Averages over 10 position pairs for stability.
    """
    n_keys, key_len = keys.shape
    if n_keys < 200:
        return 0.0

    n = n_keys
    n_pairs = min(10, key_len - 1)
    g_stats = []

    for p in range(n_pairs):
        q = p + 1
        xb = keys[:, p] >> 4  # top 4 bits → 16 bins
        yb = keys[:, q] >> 4
        joint = np.zeros((16, 16), dtype=np.float64)
        np.add.at(joint, (xb, yb), 1)
        joint_p = joint / n
        px = joint_p.sum(axis=1)
        py = joint_p.sum(axis=0)

        mi = 0.0
        for a in range(16):
            if px[a] < 1e-15:
                continue
            for b in range(16):
                if joint_p[a, b] < 1e-15 or py[b] < 1e-15:
                    continue
                mi += joint_p[a, b] * np.log(joint_p[a, b] / (px[a] * py[b]))
        g_stats.append(2.0 * n * mi)  # G-test statistic

    if not g_stats:
        return 0.0

    mean_g = np.mean(g_stats)

    # G-statistic converges to χ²(225) as N→∞
    # Empirically: mean≈225+255/N, std≈6.5 (nearly constant across N)
    null_mean = 225.0 + 15600.0 / n  # small-sample bias correction
    null_std = 6.5
    if null_std < 1e-15:
        return 0.0

    z = (mean_g - null_mean) / null_std
    return float(z)


def strategy_min_entropy(keys):
    """Min-entropy (Rényi H∞) Z-score.

    H∞ = -log₂(max_i p_i). Most conservative entropy measure.
    Used by NIST SP 800-90B for entropy source validation.
    More sensitive to distributional peaks than Shannon entropy.

    Negative Z = dominant byte value exists (entropy deficit).
    Empirically calibrated null mean and std (ref N=160000 bytes).
    """
    n_keys, key_len = keys.shape
    if n_keys < 100:
        return 0.0

    flat = keys.ravel()
    n = len(flat)
    hist = np.bincount(flat, minlength=256).astype(np.float64)
    max_freq = float(np.max(hist))
    if max_freq <= 0:
        return 0.0

    h_inf = -math.log2(max_freq / n)

    # Empirically calibrated: at N=160000, mean(H∞)=7.8425, std=0.02026
    # Both scale with n (Gumbel extreme value)
    ref_n = 160000
    ref_mean = 7.8425
    ref_std = 0.02026
    # H∞ expected value shifts logarithmically: H_max - E[max_freq/n] ∝ sqrt(ln(K)/n)
    null_mean = 8.0 - (8.0 - ref_mean) * math.sqrt(ref_n / n)
    null_std = ref_std * math.sqrt(ref_n / n)
    if null_std < 1e-15:
        return 0.0

    z = (h_inf - null_mean) / null_std
    return float(z)


def strategy_permutation_entropy(keys):
    """Permutation entropy (Bandt-Pompe) Z-score.

    Detects deterministic structure that Shannon entropy COMPLETELY MISSES.
    Sliding window of length m=5 (120 ordinal patterns = 5!).
    For random: H_perm ≈ H_max - (120-1)/(2·n·ln2).
    Negative Z = too orderly (deterministic structure in byte ordering).

    Empirically calibrated null std (ref N=5000×32=160000 bytes, window m=5).
    """
    n_keys, key_len = keys.shape
    if n_keys < 200:
        return 0.0

    stream = keys.ravel()
    n = min(len(stream), 50000)  # cap for speed
    stream = stream[:n]
    m = 5
    n_patterns = math.factorial(m)  # 120

    if n < m + 100:
        return 0.0

    # Count ordinal patterns
    n_windows = n - m + 1
    counts = np.zeros(n_patterns, dtype=np.int64)

    # Encode each ordinal pattern as an index via Lehmer code
    for i in range(n_windows):
        window = stream[i:i + m]
        order = np.argsort(window, kind='stable')
        # Lehmer code to pattern index
        idx = 0
        remaining = list(range(m))
        for j in range(m):
            pos = remaining.index(order[j])
            idx = idx * (m - j) + pos
            remaining.pop(pos)
        counts[idx] += 1

    probs = counts / float(n_windows)
    probs = probs[probs > 0]
    h_perm = -float(np.sum(probs * np.log2(probs)))

    h_max = math.log2(n_patterns)  # log2(120) = 6.907
    # Empirically calibrated mean at ref_n=50000
    # Bias correction: use empirical mean instead of theoretical (closer fit)
    ref_nw = 49996
    h_expected = h_max - (n_patterns - 1) / (2.0 * n_windows * math.log(2))
    # Fine-tune: at ref_nw, empirical mean is 6.905093 vs theoretical 6.905174
    # Adjust for sample size
    h_expected -= 0.000081 * (ref_nw / n_windows)

    # Empirically calibrated std at ref_n=50000: 0.000293
    # Scale: std ∝ 1/sqrt(n_windows)
    ref_std = 0.000293
    null_std = ref_std * math.sqrt(ref_nw / n_windows)
    if null_std < 1e-15:
        return 0.0

    z = (h_perm - h_expected) / null_std
    return float(z)  # negative = too orderly


def strategy_corr_matrix_chi2(keys):
    """Chi-squared Z-score of the full bit-pair correlation matrix.

    Computes ALL pairwise correlations between output bits, then tests
    whether the sum of squared correlations exceeds what random data produces.
    Under null: each z² ~ chi²(1), sum of z² ~ chi²(n_pairs).

    This test exploits the .causal chain insight: individual bit correlations
    may be sub-threshold, but the AGGREGATE excess across all pairs reveals
    incomplete diffusion. Inspired by the causal inference amplification
    principle (Foss 2026): weak individual signals become detectable through
    systematic accumulation.

    Positive Z = more total correlation than random (structure present).
    """
    n_keys, key_len = keys.shape
    if n_keys < 500:
        return 0.0

    # Use all 256 bits (32 bytes)
    bits = np.unpackbits(keys, axis=1).astype(np.float64)
    n_b = min(bits.shape[1], 256)
    bits = bits[:, :n_b]

    std_null = 1.0 / math.sqrt(n_keys)

    # Correlation matrix via normalized dot product
    bits_centered = bits - bits.mean(axis=0, keepdims=True)
    stds = bits.std(axis=0)
    stds[stds < 1e-10] = 1.0
    bits_norm = bits_centered / stds
    corr = (bits_norm.T @ bits_norm) / n_keys
    np.fill_diagonal(corr, 0)

    z_matrix = corr / std_null

    # Sum of squared Z-values for all unique pairs
    upper = z_matrix[np.triu_indices(n_b, k=1)]
    n_pairs = len(upper)
    sum_z2 = float(np.sum(upper ** 2))

    # Under null: sum_z2 ~ chi²(n_pairs), mean=n_pairs, var=2*n_pairs
    z = (sum_z2 - n_pairs) / math.sqrt(2.0 * n_pairs)
    return float(z)


def strategy_multi_lag_ac(keys):
    """Multi-lag autocorrelation Z-score via Ljung-Box statistic.

    Existing autocorrelation only tests lag-1. This tests lags {1,2,4,8,16,32,64}
    to catch cipher-specific block structure:
    - Speck 32/64: lag-4 (4-byte block in CTR output)
    - Blowfish: lag-8 (8-byte block)
    - AES: lag-16 (16-byte block)
    - RC4: lag-256/key_length from KSA

    Uses Ljung-Box Q statistic. Under null: Q ~ χ²(7).
    Positive Z = multi-lag structure present.
    """
    n_keys, key_len = keys.shape
    if n_keys < 200:
        return 0.0

    stream = keys.ravel().astype(np.float64) - 127.5
    n = len(stream)
    var = np.var(stream)
    if var < 1e-10:
        return 100.0

    lags = [1, 2, 4, 8, 16, 32, 64]
    lags = [k for k in lags if k < n - 1]
    n_lags = len(lags)
    if n_lags == 0:
        return 0.0

    # Compute autocorrelations and Ljung-Box Q
    Q = 0.0
    signed_sum = 0.0
    for k in lags:
        r_k = float(np.mean(stream[:n - k] * stream[k:])) / var
        Q += (r_k ** 2) / (n - k)
        signed_sum += r_k
    Q *= n * (n + 2)

    # Under null: Q ~ χ²(n_lags). Mean=n_lags, Var=2*n_lags
    expected_Q = float(n_lags)
    std_Q = math.sqrt(2.0 * n_lags)

    z_ljung = (Q - expected_Q) / std_Q

    # Also compute signed aggregate for directional info
    signed_z = signed_sum * math.sqrt(n) / math.sqrt(n_lags)

    # Return whichever has larger magnitude (signed_z preserves direction)
    if abs(signed_z) > abs(z_ljung):
        return float(signed_z)
    return float(z_ljung)


# ═══════════════════════════════════════════════════════════════
# STRATEGY REGISTRY
# ═══════════════════════════════════════════════════════════════

STRATEGIES = {
    # Crypto (IEEE paper)
    'bit_correlation': strategy_bit_correlation,
    'xor_distribution': strategy_xor_distribution,
    'parity_chain': strategy_parity_chain,
    'cross_bit': strategy_cross_bit,
    # Implementation
    'block_repetition': strategy_block_repetition,
    'byte_frequency': strategy_byte_frequency,
    'seq_correlation': strategy_seq_correlation,
    'entropy': strategy_entropy,
    'runs': strategy_runs,
    'spectral': strategy_spectral,
    'compression': strategy_compression,
    'autocorrelation': strategy_autocorrelation,
    # Distribution moments (Task 1)
    'byte_skewness': strategy_byte_skewness,
    'byte_kurtosis': strategy_byte_kurtosis,
    # New strategies (Tasks 2-8)
    'multi_lag_ac': strategy_multi_lag_ac,
    'permutation_entropy': strategy_permutation_entropy,
    'min_entropy': strategy_min_entropy,
    'mutual_information': strategy_mutual_information,
    'approx_entropy': strategy_approx_entropy,
    'matrix_rank': strategy_matrix_rank,
    'linear_complexity': strategy_linear_complexity,
    'corr_matrix_chi2': strategy_corr_matrix_chi2,
}

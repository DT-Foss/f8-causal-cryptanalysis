#!/usr/bin/env python3
"""live-casiv2 engine: signed Z-score composite with chi(k) null distribution.

Architecture:
- 24 strategies (21 byte-level + 3 temporal), each returns signed float Z
- Composite ||Z|| = sqrt(sum of Z_i²) ~ chi(k_eff) under null
- Each Z_i ~ N(0,1) under null by construction
- Direction information: sign tells you WHICH WAY the weakness goes

Null distribution (CF532):
- 22 active axes under null (block_repetition + compression are signal-only)
- byte_frequency ↔ entropy correlated (r≈-0.98)
- Effective df ≈ 22 → ||Z|| ~ chi(22) under null (KS p=0.47)
- Thresholds calibrated against empirical null at N=5000

V1 used: signal_total / baseline_total (ratio normalization, unsigned counts)
V2 uses: ||Z|| with known null distribution (no baseline needed)
"""

import math
import os
import time
import numpy as np

from .strategies import STRATEGIES
from .temporal import TEMPORAL_STRATEGIES


# ═══════════════════════════════════════════════════════════════
# STRATEGY NAME LISTS
# ═══════════════════════════════════════════════════════════════

CRYPTO_STRATEGY_NAMES = [
    'bit_correlation', 'xor_distribution', 'parity_chain', 'cross_bit',
]

IMPL_STRATEGY_NAMES = [
    'block_repetition', 'byte_frequency', 'seq_correlation',
    'entropy', 'runs', 'spectral', 'compression', 'autocorrelation',
    'byte_skewness', 'byte_kurtosis', 'multi_lag_ac', 'permutation_entropy',
    'min_entropy', 'mutual_information', 'approx_entropy', 'matrix_rank',
    'linear_complexity', 'corr_matrix_chi2',
]

TEMPORAL_STRATEGY_NAMES = [
    'temporal_adj_corr', 'temporal_trend', 'temporal_variance',
]

STRATEGY_NAMES = CRYPTO_STRATEGY_NAMES + IMPL_STRATEGY_NAMES + TEMPORAL_STRATEGY_NAMES

N_STRATEGIES = len(STRATEGY_NAMES)
N_CRYPTO = len(CRYPTO_STRATEGY_NAMES)

# CF532: effective degrees of freedom under null (24 strategies)
# block_repetition + compression are signal-only (std=0 under null)
# byte_frequency ↔ entropy correlated (r≈-0.98)
# Null ||Z|| ~ chi(22) at N=5000 (KS p=0.47)
# Null mean ≈ 4.62, std ≈ 0.84, p95 ≈ 5.98
EFFECTIVE_DF = 22


# ═══════════════════════════════════════════════════════════════
# CORE FUNCTIONS
# ═══════════════════════════════════════════════════════════════

def compute_profile(keys, rng=None):
    """Compute the full 24-axis signed Z-score profile.

    Args:
        keys: np.ndarray of shape (n_keys, key_size), uint8
        rng: optional numpy.random.Generator for temporal strategies

    Returns:
        np.ndarray of shape (24,) — signed Z-scores for each strategy.
        Order matches STRATEGY_NAMES.
    """
    if rng is None:
        rng = np.random.default_rng()

    z_scores = np.zeros(N_STRATEGIES)

    # 12 byte-level strategies (analytical Z-scores, fast)
    for i, name in enumerate(CRYPTO_STRATEGY_NAMES + IMPL_STRATEGY_NAMES):
        func = STRATEGIES[name]
        z_scores[i] = func(keys)

    # 3 temporal strategies (permutation Z-scores, slower)
    offset = len(CRYPTO_STRATEGY_NAMES) + len(IMPL_STRATEGY_NAMES)
    for i, name in enumerate(TEMPORAL_STRATEGY_NAMES):
        func = TEMPORAL_STRATEGIES[name]
        z_scores[offset + i] = func(keys, rng=rng)

    return z_scores


def compute_casi(keys, rng=None):
    """Compute V2 CASI composite score: ||Z|| = sqrt(sum of Z_i²).

    Under null (random data): ||Z|| ~ chi(22) (CF532: effective df=22)
    Null mean ≈ 4.62, std ≈ 0.84
    Threshold at ||Z|| ≈ 6.0 gives ~5% empirical FPR.

    Returns:
        float >= 0
    """
    z = compute_profile(keys, rng=rng)
    return float(np.sqrt(np.sum(z ** 2)))


def compute_crypto_profile(keys):
    """Compute only the 4 crypto strategy Z-scores (IEEE paper compatible).

    Returns:
        np.ndarray of shape (4,) — signed Z-scores for crypto strategies.
    """
    z_scores = np.zeros(N_CRYPTO)
    for i, name in enumerate(CRYPTO_STRATEGY_NAMES):
        func = STRATEGIES[name]
        z_scores[i] = func(keys)
    return z_scores


def compute_crypto_casi(keys):
    """Composite of 4 crypto strategies only.

    Under null: ||Z|| ~ chi(4), mean ≈ 1.88, sd ≈ 0.72
    Threshold at ||Z|| ≈ 3.0 gives ~5% FPR.
    """
    z = compute_crypto_profile(keys)
    return float(np.sqrt(np.sum(z ** 2)))


def compute_fast_profile(keys):
    """Compute byte-level-only profile (skip slow temporal strategies).

    Returns:
        np.ndarray of shape (21,) — signed Z-scores for byte-level strategies only.
    """
    byte_names = CRYPTO_STRATEGY_NAMES + IMPL_STRATEGY_NAMES
    z_scores = np.zeros(len(byte_names))
    for i, name in enumerate(byte_names):
        func = STRATEGIES[name]
        z_scores[i] = func(keys)
    return z_scores


def compute_fast_casi(keys):
    """Fast CASI using only byte-level strategies (no temporal permutations).

    Under null: ||Z|| ~ chi(19), mean ≈ 4.28, p95 ≈ 5.6
    ~100x faster than full profile.
    """
    z = compute_fast_profile(keys)
    return float(np.sqrt(np.sum(z ** 2)))


def deep_scan(keys, n_splits=10, rng=None):
    """Maximum-power analysis using split-half stability testing.

    Splits data into n_splits subsets, computes profile for each,
    identifies strategies with CONSISTENT signal (not noise).
    Returns composite of only the stable strategies.
    """
    if rng is None:
        rng = np.random.default_rng(42)

    n_keys = keys.shape[0]
    if n_keys < 500:
        return compute_casi(keys, rng=rng)

    split_size = n_keys // n_splits
    byte_names = CRYPTO_STRATEGY_NAMES + IMPL_STRATEGY_NAMES
    n_byte = len(byte_names)

    # Compute profile on each split
    split_profiles = np.zeros((n_splits, n_byte))
    for s in range(n_splits):
        start = s * split_size
        end = start + split_size
        split_keys = keys[start:end]
        for i, name in enumerate(byte_names):
            func = STRATEGIES[name]
            split_profiles[s, i] = func(split_keys)

    # Strategies with consistent sign across splits are real signal
    mean_z = np.mean(split_profiles, axis=0)
    sign_consistency = np.abs(np.mean(np.sign(split_profiles), axis=0))

    # Use only strategies where >70% of splits agree on sign AND mean|Z| > 0.5
    mask = (sign_consistency > 0.7) & (np.abs(mean_z) > 0.5)

    # Full-data profile for selected strategies
    full_z = np.zeros(n_byte)
    for i, name in enumerate(byte_names):
        if mask[i]:
            func = STRATEGIES[name]
            full_z[i] = func(keys)

    selected_z = full_z[mask]
    if len(selected_z) == 0:
        return 0.0

    composite = float(np.sqrt(np.sum(selected_z ** 2)))
    return composite


# Popcount and parity lookup tables for fisher_amplify
_PARITY_LUT = np.array([bin(i).count('1') % 2 for i in range(256)], dtype=np.uint8)


def fisher_amplify(keys, baseline_seed=0xBA5E):
    """Fisher amplification: three-pass sub-threshold signal combination.

    Ported from live-casi V1's compute_amplified_score. Runs ~4000 individual
    tests and combines via Fisher's method to detect weak signals that fall
    below individual Z-score thresholds but collectively constitute evidence.

    Architecture (inspired by .causal 3-pass inference engine):
      Pass 1 (Exact):    Bit-flip deviation at 8 XOR strides
      Pass 2 (Semantic):  Cross-position parity correlation + differential equality
      Pass 3 (Fuzzy):     Second-order differences, nibble chi2, GF(2) combination

    Returns:
        dict with 'fisher_z' (signed Z-score of Fisher statistic),
        'n_tests', 'pass_counts', 'casi_standard' (for comparison)
    """
    from scipy import stats as _stats

    n_keys, key_len = keys.shape

    # Generate baseline for comparison (fixed seed for reproducibility)
    baseline_keys = np.frombuffer(
        np.random.RandomState(baseline_seed).bytes(n_keys * key_len),
        dtype=np.uint8,
    ).reshape(n_keys, key_len)

    def _collect_z_scores(k):
        """Collect unsigned |Z| scores from three-pass analysis."""
        n = k.shape[0]
        all_z = []
        pass_counts = [0, 0, 0]

        # ═══ PASS 1: Bit-flip at multiple XOR strides ═══
        for stride in range(1, 9):
            if n < stride + 500:
                continue
            diffs = k[stride:] ^ k[:-stride]
            nd = diffs.shape[0]
            bits = np.unpackbits(diffs, axis=1)[:, :min(key_len * 8, 256)]
            exp = nd / 2.0
            std = math.sqrt(nd * 0.25)
            z_flip = np.abs(np.sum(bits, axis=0).astype(np.float64) - exp) / std
            all_z.extend(z_flip.tolist())
        pass_counts[0] = len(all_z)

        # ═══ PASS 2: Cross-position parity correlation ═══
        exp_half = n / 2.0
        std_half = math.sqrt(n * 0.25)
        masks = [0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80]
        for i in range(min(key_len, 16)):
            for j in range(i + 1, min(i + 3, 16)):
                for ma in masks:
                    for mb in masks:
                        pa = _PARITY_LUT[k[:, i] & ma]
                        pb = _PARITY_LUT[k[:, j] & mb]
                        agrees = np.sum(pa == pb)
                        z = abs(float(agrees) - exp_half) / std_half
                        all_z.append(z)

        for stride in [1, 2, 4]:
            if n < stride + 1000:
                continue
            diffs = k[stride:] ^ k[:-stride]
            nd = diffs.shape[0]
            for i in range(min(key_len, 16)):
                for j in range(i + 1, min(i + 4, key_len)):
                    same = int(np.sum(diffs[:, i] == diffs[:, j]))
                    exp_s = nd / 256.0
                    std_s = math.sqrt(exp_s * (1 - 1.0 / 256))
                    z = abs(same - exp_s) / std_s
                    all_z.append(z)
        pass_counts[1] = len(all_z) - pass_counts[0]

        # ═══ PASS 3: Multi-transform re-test ═══
        # Second-order differences
        for stride in [1, 2]:
            if n < stride * 2 + 500:
                continue
            diff1 = k[stride:] ^ k[:-stride]
            diff2 = diff1[stride:] ^ diff1[:-stride]
            nd2 = diff2.shape[0]
            if nd2 < 500:
                continue
            bits2 = np.unpackbits(diff2, axis=1)[:, :128]
            exp2 = nd2 / 2.0
            std2 = math.sqrt(nd2 * 0.25)
            z2 = np.abs(np.sum(bits2, axis=0).astype(np.float64) - exp2) / std2
            all_z.extend(z2.tolist())

        # Nibble-level chi2
        for stride in [1, 2, 4]:
            if n < stride + 500:
                continue
            diffs = k[stride:] ^ k[:-stride]
            nd = diffs.shape[0]
            for pos in range(min(key_len, 16)):
                for shift in [4, 0]:  # high nibble, low nibble
                    nibs = (diffs[:, pos] >> shift) & 0x0F
                    hist = np.bincount(nibs, minlength=16).astype(np.float64)
                    exp_n = nd / 16.0
                    chi = float(np.sum((hist - exp_n) ** 2 / exp_n))
                    z = abs((chi - 15) / math.sqrt(30))
                    all_z.append(z)

        # GF(2) byte-XOR of position pairs
        for stride in [1, 2]:
            if n < stride + 500:
                continue
            diffs = k[stride:] ^ k[:-stride]
            nd = diffs.shape[0]
            for i in range(min(key_len, 8)):
                for j in range(i + 1, min(i + 3, key_len)):
                    combined = diffs[:, i] ^ diffs[:, j]
                    hist = np.bincount(combined, minlength=256).astype(np.float64)
                    exp_c = nd / 256.0
                    chi = float(np.sum((hist - exp_c) ** 2 / exp_c))
                    z = abs((chi - 255) / math.sqrt(510))
                    all_z.append(z)
        pass_counts[2] = len(all_z) - pass_counts[0] - pass_counts[1]

        return np.array(all_z), pass_counts

    # Collect z-scores for cipher and baseline
    z_cipher, pass_cipher = _collect_z_scores(keys)
    z_baseline, pass_baseline = _collect_z_scores(baseline_keys)

    # Fisher's combined test
    p_cipher = 2 * (1 - _stats.norm.cdf(z_cipher))
    p_cipher = np.clip(p_cipher, 1e-300, 1.0)
    fisher_cipher = -2.0 * np.sum(np.log(p_cipher))

    p_baseline = 2 * (1 - _stats.norm.cdf(z_baseline))
    p_baseline = np.clip(p_baseline, 1e-300, 1.0)
    fisher_baseline = -2.0 * np.sum(np.log(p_baseline))

    k = len(z_cipher)
    expected_fisher = 2 * k
    std_fisher = math.sqrt(4 * k)

    fisher_z = (fisher_cipher - expected_fisher) / std_fisher
    baseline_z = (fisher_baseline - expected_fisher) / std_fisher

    # Standard CASI for comparison
    casi_std = compute_fast_casi(keys)

    return {
        'fisher_z': float(fisher_z),
        'baseline_z': float(baseline_z),
        'amplified_casi': float(fisher_cipher / max(fisher_baseline, 1.0)),
        'casi_standard': float(casi_std),
        'n_tests': int(k),
        'pass_counts': pass_cipher,
    }


def cross_round_independence(out_R, out_R1, block_bytes=None, bpw=None,
                             shift=5, alpha=None, beta=None):
    """F8: Cross-round quantized independence test.

    Detects information leak from out_x(R) into diff_y(R→R+1) caused by
    modular addition + rotation in ARX ciphers. Returns signed Z-score.

    Args:
        out_R: bytes or ndarray — cipher output at round R
        out_R1: bytes or ndarray — cipher output at round R+1 (same key/counter)
        block_bytes: int — block size in bytes (if None: auto-detect from data width)
        bpw: int — bytes per half-word (if None: block_bytes // 2)
        shift: int — quantization shift (default 5, 8 bins)
        alpha: int — rotation parameter (if known, test only crossover pairs)
        beta: int — rotation parameter (if known, exclude dead bits from Z)

    Returns:
        float — signed Z-score. Positive = structure detected. Z ~ N(0,1) under null.

    Modes:
        - Informed (block_bytes + bpw given): test only out_x→diff_y crossover pairs
        - Black-box (defaults): test all pairs within auto-detected block width
    """
    from scipy import stats as _stats

    # Convert to uint8 arrays
    if isinstance(out_R, (bytes, bytearray)):
        out_R = np.frombuffer(out_R, dtype=np.uint8)
    if isinstance(out_R1, (bytes, bytearray)):
        out_R1 = np.frombuffer(out_R1, dtype=np.uint8)

    if out_R.ndim == 1:
        if block_bytes is None:
            block_bytes = 4  # default to Speck 32/64
        out_R = out_R[:len(out_R) // block_bytes * block_bytes].reshape(-1, block_bytes)
        out_R1 = out_R1[:len(out_R1) // block_bytes * block_bytes].reshape(-1, block_bytes)

    if bpw is None:
        bpw = block_bytes // 2

    n = min(out_R.shape[0], out_R1.shape[0])
    if n < 100:
        return 0.0
    out_R = out_R[:n]
    out_R1 = out_R1[:n]
    bb = out_R.shape[1]

    diff = out_R ^ out_R1
    n_bins = 2 ** (8 - shift)
    out_q = out_R >> shift
    diff_q = diff >> shift
    dof = (n_bins - 1) ** 2

    # Collect chi2 values for the test
    chi2_values = []

    if bpw is not None and bpw < bb:
        # Informed mode: only test out_x[i] vs diff_y[j] (Feistel crossover)
        for i in range(bpw):
            for j in range(bpw, bb):
                table = np.zeros((n_bins, n_bins), dtype=float)
                np.add.at(table, (out_q[:, i], diff_q[:, j]), 1)
                rs = table.sum(axis=1, keepdims=True)
                cs = table.sum(axis=0, keepdims=True)
                exp = rs * cs / n
                valid = exp > 5
                if np.sum(valid) < n_bins:
                    continue
                chi2 = float(np.sum((table[valid] - exp[valid]) ** 2 / exp[valid]))
                chi2_values.append(chi2)
    else:
        # Black-box mode: test all pairs
        for i in range(bb):
            for j in range(bb):
                table = np.zeros((n_bins, n_bins), dtype=float)
                np.add.at(table, (out_q[:, i], diff_q[:, j]), 1)
                rs = table.sum(axis=1, keepdims=True)
                cs = table.sum(axis=0, keepdims=True)
                exp = rs * cs / n
                valid = exp > 5
                if np.sum(valid) < n_bins:
                    continue
                chi2 = float(np.sum((table[valid] - exp[valid]) ** 2 / exp[valid]))
                chi2_values.append(chi2)

    if not chi2_values:
        return 0.0

    # Convert chi2 values to Z-scores via Fisher's method
    # Each chi2 ~ chi2(dof) under null. Transform to p-values, then to Z.
    # Fisher's combined statistic: -2 * sum(log(p)) ~ chi2(2k)
    log_p_sum = 0.0
    k = len(chi2_values)
    for chi2 in chi2_values:
        p = float(_stats.chi2.sf(chi2, dof))
        p = max(p, 1e-300)  # avoid log(0)
        log_p_sum += math.log(p)

    fisher_stat = -2.0 * log_p_sum
    fisher_dof = 2 * k
    # Normalize to Z ~ N(0,1): (X - mu) / sigma where X ~ chi2(2k)
    z = (fisher_stat - fisher_dof) / math.sqrt(2.0 * fisher_dof)

    return float(z)


def cross_round_mi(out_R, out_R1, block_bytes=None, bpw=None,
                   alpha=None, beta=None):
    """F8-MI: Bit-level mutual information cross-round test.

    More sensitive than chi2-based cross_round_independence because it operates
    at the natural resolution of the rotation-leak (individual bits, not
    quantized bytes). Returns signed Z-score.

    Measures MI between each bit of x(R) and the corresponding shifted bit of
    diff_y(R→R+1). Under null: MI ≈ 0 for all pairs. Under signal: MI > 0
    on the α-shifted diagonal, with β dead bits.

    Args:
        out_R: bytes — cipher output at round R
        out_R1: bytes — cipher output at round R+1 (same key/counter)
        block_bytes: int — block size in bytes (auto-detect if None)
        bpw: int — bytes per half-word (block_bytes // 2 if None)
        alpha: int — rotation parameter. If known, test only diagonal pairs.
                     If None, test all WS×WS bit pairs (black-box).
        beta: int — if known, exclude dead bit positions from aggregation.

    Returns:
        float — signed Z-score. Positive = MI detected. Z ~ N(0,1) under null.
    """
    # Convert to uint8 arrays
    if isinstance(out_R, (bytes, bytearray)):
        out_R = np.frombuffer(out_R, dtype=np.uint8)
    if isinstance(out_R1, (bytes, bytearray)):
        out_R1 = np.frombuffer(out_R1, dtype=np.uint8)

    if out_R.ndim == 1:
        if block_bytes is None:
            block_bytes = 4
        out_R = out_R[:len(out_R) // block_bytes * block_bytes].reshape(-1, block_bytes)
        out_R1 = out_R1[:len(out_R1) // block_bytes * block_bytes].reshape(-1, block_bytes)

    if bpw is None:
        bpw = block_bytes // 2

    n = min(out_R.shape[0], out_R1.shape[0])
    if n < 100:
        return 0.0
    out_R = out_R[:n]
    out_R1 = out_R1[:n]
    bb = out_R.shape[1]
    ws = bpw * 8  # word size in bits

    # Reconstruct half-words from bytes (big-endian)
    x_R = np.zeros(n, dtype=np.uint64)
    y_R = np.zeros(n, dtype=np.uint64)
    y_R1 = np.zeros(n, dtype=np.uint64)
    for b in range(bpw):
        sh = 8 * (bpw - 1 - b)
        x_R |= out_R[:, b].astype(np.uint64) << sh
        y_R |= out_R[:, bpw + b].astype(np.uint64) << sh
        y_R1 |= out_R1[:, bpw + b].astype(np.uint64) << sh

    diff_y = y_R ^ y_R1

    # MI computation for binary variables
    def _mi_bits(a, b_arr):
        """MI between two binary arrays. Returns MI in bits."""
        n00 = int(np.sum((a == 0) & (b_arr == 0)))
        n01 = int(np.sum((a == 0) & (b_arr == 1)))
        n10 = int(np.sum((a == 1) & (b_arr == 0)))
        n11 = int(np.sum((a == 1) & (b_arr == 1)))
        nn = n00 + n01 + n10 + n11
        if nn == 0:
            return 0.0
        H_ab = 0.0
        for c in (n00, n01, n10, n11):
            p = c / nn
            if p > 0:
                H_ab -= p * math.log(p)  # nats
        pa = (n10 + n11) / nn
        pb = (n01 + n11) / nn
        Ha = -pa * math.log(pa) - (1 - pa) * math.log(1 - pa) if 0 < pa < 1 else 0.0
        Hb = -pb * math.log(pb) - (1 - pb) * math.log(1 - pb) if 0 < pb < 1 else 0.0
        return max(0.0, Ha + Hb - H_ab)

    # Collect MI values for all tested bit pairs
    mi_values = []

    if alpha is not None:
        # Informed mode: only test the α-shifted diagonal
        dead_set = set()
        if beta is not None:
            dead_set = {(alpha + d) % ws for d in range(beta)}
        for i in range(ws):
            if i in dead_set:
                continue
            j = (i - alpha) % ws
            xb = ((x_R >> i) & 1).astype(np.uint8)
            dyb = ((diff_y >> j) & 1).astype(np.uint8)
            mi_values.append(_mi_bits(xb, dyb))
    else:
        # Black-box: test all pairs (WS × WS), keep max per x-bit
        for i in range(ws):
            best_mi = 0.0
            for j in range(ws):
                xb = ((x_R >> i) & 1).astype(np.uint8)
                dyb = ((diff_y >> j) & 1).astype(np.uint8)
                best_mi = max(best_mi, _mi_bits(xb, dyb))
            mi_values.append(best_mi)

    if not mi_values:
        return 0.0

    total_mi = sum(mi_values)

    # Permutation test: shuffle diff_y to break real correlations,
    # recompute MI, repeat n_perm times to build null distribution.
    # Z = (real - mean_null) / std_null. Works for any k, any WS.
    n_perm = 20
    rng_perm = np.random.default_rng(42)
    null_totals = []
    for _ in range(n_perm):
        perm_idx = rng_perm.permutation(n)
        diff_y_perm = diff_y[perm_idx]
        perm_mi = []
        if alpha is not None:
            dead_set_p = set()
            if beta is not None:
                dead_set_p = {(alpha + d) % ws for d in range(beta)}
            for i in range(ws):
                if i in dead_set_p:
                    continue
                j = (i - alpha) % ws
                xb = ((x_R >> i) & 1).astype(np.uint8)
                dyb = ((diff_y_perm >> j) & 1).astype(np.uint8)
                perm_mi.append(_mi_bits(xb, dyb))
        else:
            for i in range(ws):
                best_mi = 0.0
                for j in range(ws):
                    xb = ((x_R >> i) & 1).astype(np.uint8)
                    dyb = ((diff_y_perm >> j) & 1).astype(np.uint8)
                    best_mi = max(best_mi, _mi_bits(xb, dyb))
                perm_mi.append(best_mi)
        null_totals.append(sum(perm_mi))

    null_mean = float(np.mean(null_totals))
    null_std = float(np.std(null_totals))
    if null_std < 1e-30:
        null_std = 1e-30

    z = (total_mi - null_mean) / null_std
    return float(z)


# ═══════════════════════════════════════════════════════════════
# ARX LEAK PREDICTION MODEL
# ═══════════════════════════════════════════════════════════════

def predict_arx_leak(alpha, beta, word_size=16, mechanism='speck'):
    """Predict F8 carry-leak profile for an ARX round function.

    Based on the empirically derived leak-rate formula (R²=0.999997)
    and the Threefish raw-carry mechanism.

    Args:
        alpha: int — ROR rotation constant (irrelevant for MI magnitude,
               determines dead-bit position only)
        beta: int — ROL rotation constant (determines leak magnitude)
        word_size: int — half-word size in bits (default 16 for Speck 32/64)
        mechanism: str — 'speck' (β-masking) or 'threefish' (raw carry, β_eff=0)

    Returns:
        dict with:
            'vulnerable': bool — True if signal expected
            'mechanism': str — leak mechanism type
            'mi_per_pair': float — expected MI per active bit pair
            'n_active': int — number of active bit pairs
            'n_dead': int — number of dead bit positions
            'dead_positions': list — bit positions masked by rotation
            'total_mi': float — sum of MI across all active pairs
            'expected_z': float — expected Z-score at N=50000 (5 seeds, 20 perms)
            'leak_rate': float — total_mi / word_size (fractional leak)
    """
    if mechanism == 'threefish':
        # Threefish-type: raw carry-chain leak, rotation is irrelevant
        # MI decays exponentially from bit 0: MI(bit_i) ≈ exp(-1.42 * i)
        # Empirically: ~5 active bits regardless of word_size or rotation
        n_active = min(5, word_size)
        mi_values = [0.78 * math.exp(-1.42 * i) for i in range(n_active)]
        total_mi = sum(mi_values)
        mi_per_pair = total_mi / n_active if n_active > 0 else 0
        return {
            'vulnerable': True,
            'mechanism': 'raw_carry (β_eff=0)',
            'mi_per_pair': mi_per_pair,
            'n_active': n_active,
            'n_dead': 0,
            'dead_positions': [],
            'total_mi': total_mi,
            'expected_z': 5500.0,  # empirical: Z≈5000-6700 at N=50K
            'leak_rate': total_mi / word_size,
        }

    # Speck-type: β-masking mechanism
    # MI_per_pair(β) = 0.78 · exp(-1.42·β)
    # Dead bits at positions [α, α+1, ..., α+β-1] mod WS
    if beta >= 5:
        return {
            'vulnerable': False,
            'mechanism': 'β-masking (β≥5, below noise floor)',
            'mi_per_pair': 0.0,
            'n_active': 0,
            'n_dead': beta,
            'dead_positions': [(alpha + d) % word_size for d in range(beta)],
            'total_mi': 0.0,
            'expected_z': 0.0,
            'leak_rate': 0.0,
        }

    mi_per_pair = 0.78 * math.exp(-1.42 * beta)
    n_dead = beta
    n_active = word_size - n_dead
    dead_positions = [(alpha + d) % word_size for d in range(n_dead)]
    total_mi = n_active * mi_per_pair
    leak_rate = total_mi / word_size

    # Expected Z estimate: based on Speck 32/64 empirical data
    # At N=50K, β=2: Z≈5500, β=1: Z≈15000, β=3: Z≈1500, β=4: Z≈400
    # Rough scaling: Z ∝ MI × sqrt(N) × calibration_constant
    z_ref = {1: 15000, 2: 5500, 3: 1500, 4: 400}
    expected_z = z_ref.get(beta, 0.0)

    return {
        'vulnerable': True,
        'mechanism': f'β-masking (β={beta})',
        'mi_per_pair': mi_per_pair,
        'n_active': n_active,
        'n_dead': n_dead,
        'dead_positions': dead_positions,
        'total_mi': total_mi,
        'expected_z': expected_z,
        'leak_rate': leak_rate,
    }


def compile_leak_model(spec):
    """Universal Leak-Model Compiler.

    Input: A cipher specification dict describing the ARX structure.
    Output: A leak profile predicting F8 vulnerability.

    Spec format:
        {
            'name': str,
            'word_size': int,           # bits per half-word
            'additions': [              # list of additions in one round
                {
                    'topology': str,    # 'ror_add_xor' | 'add_xor_rol' | 'rot_add_xor' |
                                        # 'xor_add_rot' | 'threefish_mix' | 'bare_add'
                    'alpha': int,       # ROR constant (for Speck-type)
                    'beta': int,        # ROL constant
                }
            ],
            'has_linear_layer': bool,   # inter-round diffusion layer (SPARX, LEA)
            'additions_per_word': int,  # how many additions touch each word per round
            'cross_mixing': bool,       # do different words mix within a round (Chaskey)
        }

    Returns:
        {
            'vulnerable': bool,
            'mechanism': str,
            'expected_z': float,
            'leak_details': list of per-addition leak profiles,
            'mitigations': list of str explaining what kills the signal,
            'notes': str,
        }
    """
    name = spec.get('name', 'unknown')
    ws = spec['word_size']
    additions = spec.get('additions', [])
    has_linear = spec.get('has_linear_layer', False)
    adds_per_word = spec.get('additions_per_word', 1)
    cross_mix = spec.get('cross_mixing', False)

    # Rule 1: Linear inter-round layer kills the signal
    if has_linear:
        return {
            'vulnerable': False,
            'mechanism': 'linear layer breaks counter-monotonicity',
            'expected_z': 0.0,
            'leak_details': [],
            'mitigations': ['Inter-round linear diffusion layer'],
            'notes': f'{name}: linear layer makes F8 inputs at R+1 unrelated to R inputs. '
                     f'Even algebraic inversion of the layer does not recover signal (verified on SPARX).',
        }

    # Rule 2: Multiple additions per word per round with cross-mixing
    if adds_per_word >= 2 and cross_mix:
        return {
            'vulnerable': False,
            'mechanism': 'intra-round cross-mixing diffuses carry-leak within 2-3 rounds',
            'expected_z': 0.0,
            'leak_details': [],
            'mitigations': [f'{adds_per_word} additions/word/round', 'Cross-word mixing'],
            'notes': f'{name}: multiple interleaved additions destroy carry correlations rapidly.',
        }

    # Rule 3: Check each addition's topology
    leak_details = []
    any_vulnerable = False
    best_z = 0.0

    for add_spec in additions:
        topo = add_spec.get('topology', 'unknown')
        alpha = add_spec.get('alpha', 0)
        beta = add_spec.get('beta', 0)

        if topo in ('ror_add_xor', 'speck'):
            # Speck-type: vulnerable if β < death_threshold(WS)
            # Death threshold grows slightly with WS: ~5 at WS=16, ~7-8 at WS=64
            death_threshold = 5 + max(0, (ws - 16) // 16)
            profile = predict_arx_leak(alpha, beta, ws, mechanism='speck')
            profile['death_threshold'] = death_threshold
            leak_details.append(profile)
            if profile['vulnerable']:
                any_vulnerable = True
                best_z = max(best_z, profile['expected_z'])

        elif topo in ('threefish_mix', 'add_rot_other'):
            # Threefish-type: always vulnerable (β_eff=0)
            profile = predict_arx_leak(alpha, beta, ws, mechanism='threefish')
            leak_details.append(profile)
            any_vulnerable = True
            best_z = max(best_z, profile['expected_z'])

        elif topo == 'bare_add':
            # Pure addition: always vulnerable (maximum leak)
            profile = {
                'vulnerable': True,
                'mechanism': 'bare addition (no rotation masking)',
                'expected_z': 70000.0,
                'mi_per_pair': 0.78,
                'n_active': ws,
                'leak_rate': 0.78,
            }
            leak_details.append(profile)
            any_vulnerable = True
            best_z = max(best_z, 70000.0)

        else:
            # All other topologies: NOT vulnerable
            # ROT→ADD→XOR, ADD→XOR→ROT, XOR→ADD→ROT: rotation before/around
            # addition prevents direct carry-chain exposure
            profile = {
                'vulnerable': False,
                'mechanism': f'topology {topo}: addition output not directly exposed',
                'expected_z': 0.0,
                'mi_per_pair': 0.0,
                'n_active': 0,
            }
            leak_details.append(profile)

    # Additional check: encrypt-only (decrypt is immune)
    mitigations = []
    if any_vulnerable:
        mitigations.append('Leak is encrypt-direction only (decrypt has zero signal)')

    return {
        'vulnerable': any_vulnerable,
        'mechanism': leak_details[0]['mechanism'] if leak_details else 'no additions',
        'expected_z': best_z,
        'leak_details': leak_details,
        'mitigations': mitigations,
        'notes': f'{name}: {"VULNERABLE" if any_vulnerable else "SECURE"} against F8.',
    }


# Pre-defined cipher specs for validation
CIPHER_SPECS = {
    'speck_32_64': {
        'name': 'Speck 32/64', 'word_size': 16,
        'additions': [{'topology': 'ror_add_xor', 'alpha': 7, 'beta': 2}],
        'has_linear_layer': False, 'additions_per_word': 1, 'cross_mixing': False,
    },
    'speck_64_128': {
        'name': 'Speck 64/128', 'word_size': 32,
        'additions': [{'topology': 'ror_add_xor', 'alpha': 8, 'beta': 3}],
        'has_linear_layer': False, 'additions_per_word': 1, 'cross_mixing': False,
    },
    'speck_128_256': {
        'name': 'Speck 128/256', 'word_size': 64,
        'additions': [{'topology': 'ror_add_xor', 'alpha': 8, 'beta': 3}],
        'has_linear_layer': False, 'additions_per_word': 1, 'cross_mixing': False,
    },
    'threefish_256': {
        'name': 'Threefish-256', 'word_size': 64,
        'additions': [{'topology': 'threefish_mix', 'alpha': 0, 'beta': 14}],
        'has_linear_layer': False, 'additions_per_word': 1, 'cross_mixing': False,
    },
    'sparx_64_128': {
        'name': 'SPARX-64/128', 'word_size': 16,
        'additions': [{'topology': 'ror_add_xor', 'alpha': 7, 'beta': 2}],
        'has_linear_layer': True, 'additions_per_word': 1, 'cross_mixing': False,
    },
    'chaskey': {
        'name': 'Chaskey', 'word_size': 32,
        'additions': [
            {'topology': 'ror_add_xor', 'alpha': 0, 'beta': 5},
            {'topology': 'ror_add_xor', 'alpha': 0, 'beta': 8},
        ],
        'has_linear_layer': False, 'additions_per_word': 2, 'cross_mixing': True,
    },
    'lea_128': {
        'name': 'LEA-128', 'word_size': 32,
        'additions': [
            {'topology': 'rot_add_xor', 'alpha': 0, 'beta': 9},
            {'topology': 'rot_add_xor', 'alpha': 0, 'beta': 5},
            {'topology': 'rot_add_xor', 'alpha': 0, 'beta': 3},
        ],
        'has_linear_layer': False, 'additions_per_word': 2, 'cross_mixing': True,
    },
    'hight': {
        'name': 'HIGHT', 'word_size': 8,
        'additions': [{'topology': 'ror_add_xor', 'alpha': 0, 'beta': 3}],
        'has_linear_layer': False, 'additions_per_word': 2, 'cross_mixing': True,
    },
}


# Pre-computed predictions for known ciphers (validated 9/9)
KNOWN_CIPHER_LEAKS = {
    'speck_32_64':   predict_arx_leak(alpha=7, beta=2, word_size=16),
    'speck_48_96':   predict_arx_leak(alpha=8, beta=3, word_size=24),
    'speck_64_128':  predict_arx_leak(alpha=8, beta=3, word_size=32),
    'speck_128_256': predict_arx_leak(alpha=8, beta=3, word_size=64),
    'threefish_256': predict_arx_leak(alpha=0, beta=0, word_size=64, mechanism='threefish'),
    # These have β≥5 or diffusion layers that kill the signal:
    'hight':    {'vulnerable': False, 'mechanism': '8-bit addition diffuses too fast'},
    'lea_128':  {'vulnerable': False, 'mechanism': '3 additions + rotation diffuse by R6'},
    'chaskey':  {'vulnerable': False, 'mechanism': '4 additions/half-round, cross-mixing kills signal by R3'},
    'sparx_full': {'vulnerable': False, 'mechanism': 'linear inter-round layer breaks counter-monotonicity'},
    'sparx_arx_box': predict_arx_leak(alpha=7, beta=2, word_size=16),  # isolated ARX-box = Speck
}


def dominant_axis(profile):
    """Identify the dominant axis (largest |Z|).

    Args:
        profile: ndarray of shape (N_STRATEGIES,), (N_CRYPTO,),
                 or (N_CRYPTO + N_IMPL,) for fast profiles

    Returns:
        (axis_name: str, z_value: float, axis_index: int)
    """
    n = len(profile)
    if n == N_STRATEGIES:
        names = STRATEGY_NAMES
    elif n == N_CRYPTO:
        names = CRYPTO_STRATEGY_NAMES
    elif n == len(CRYPTO_STRATEGY_NAMES) + len(IMPL_STRATEGY_NAMES):
        names = CRYPTO_STRATEGY_NAMES + IMPL_STRATEGY_NAMES
    else:
        # Fallback: return numeric index
        idx = int(np.argmax(np.abs(profile)))
        return f"axis_{idx}", float(profile[idx]), idx
    idx = int(np.argmax(np.abs(profile)))
    return names[idx], float(profile[idx]), idx


def interpret(profile):
    """Human-readable interpretation of a V2 profile.

    Args:
        profile: ndarray of shape (15,)

    Returns:
        dict with 'composite', 'verdict', 'axes', 'dominant', 'direction', 'summary'
    """
    composite = float(np.sqrt(np.sum(np.asarray(profile) ** 2)))
    names = STRATEGY_NAMES if len(profile) == N_STRATEGIES else CRYPTO_STRATEGY_NAMES

    # Verdict based on empirical null (CF532: effective df=22 for full 24-strategy profile)
    k = len(profile)
    # Empirical ~5% FPR thresholds
    if k >= 20:
        threshold = 6.0  # chi(22): empirical p95 ≈ 5.98 at N=5000
    elif k >= 12:
        threshold = 5.0
    elif k >= 6:
        threshold = 4.0
    else:
        threshold = 3.0

    if composite < threshold * 0.6:
        verdict = 'SECURE'
    elif composite < threshold:
        verdict = 'Borderline'
    elif composite < threshold * 2:
        verdict = 'WEAK'
    else:
        verdict = 'BROKEN'

    # Per-axis details
    axes = {}
    for i, name in enumerate(names):
        z = float(profile[i])
        significance = 'significant' if abs(z) > 2.0 else 'not significant'
        direction = 'positive' if z > 0 else 'negative' if z < 0 else 'zero'
        axes[name] = {'z': z, 'significance': significance, 'direction': direction}

    # Dominant axis
    dom_name, dom_z, dom_idx = dominant_axis(profile)

    # Direction descriptions for temporal axes
    direction_meanings = {
        'temporal_adj_corr': {
            'positive': 'persistent/smooth byte patterns',
            'negative': 'alternating/choppy byte patterns',
        },
        'temporal_trend': {
            'positive': 'byte values increase over stream',
            'negative': 'byte values decrease over stream',
        },
        'temporal_variance': {
            'positive': 'byte variance grows over stream',
            'negative': 'byte variance shrinks over stream',
        },
        'autocorrelation': {
            'positive': 'persistent byte correlation (smooth)',
            'negative': 'alternating byte correlation (choppy)',
        },
        'entropy': {
            'positive': 'excess entropy (unusual)',
            'negative': 'deficit entropy (low randomness)',
        },
        'runs': {
            'positive': 'too many runs (rapid bit alternation)',
            'negative': 'too few runs (long same-bit stretches)',
        },
        'seq_correlation': {
            'positive': 'keys too different (anti-correlated)',
            'negative': 'keys too similar (correlated, nonce reuse)',
        },
    }

    direction_info = ''
    if dom_name in direction_meanings:
        d = 'positive' if dom_z > 0 else 'negative'
        direction_info = direction_meanings[dom_name].get(d, '')

    summary = f"||Z|| = {composite:.2f} ({verdict}). "
    summary += f"Dominant: {dom_name} Z={dom_z:+.2f}"
    if direction_info:
        summary += f" ({direction_info})"

    return {
        'composite': composite,
        'verdict': verdict,
        'axes': axes,
        'dominant': {'name': dom_name, 'z': dom_z, 'index': dom_idx},
        'direction': direction_info,
        'summary': summary,
    }


# ═══════════════════════════════════════════════════════════════
# AUTOMATED DIAGNOSIS
# ═══════════════════════════════════════════════════════════════

# Weakness signature patterns: (strategy, sign, min_z) tuples
_WEAKNESS_SIGNATURES = {
    'nonce_reuse': {
        'description': 'Nonce or key reuse detected — identical or near-identical blocks',
        'indicators': [('seq_correlation', -1, 3.0), ('block_repetition', 1, 1.0)],
        'remediation': 'Ensure unique nonce/IV per encryption. Use a counter or random nonce.',
    },
    'weak_prng': {
        'description': 'Weak PRNG — output has low entropy or byte bias',
        'indicators': [('entropy', -1, 2.0), ('byte_frequency', 1, 2.0), ('min_entropy', -1, 2.0)],
        'remediation': 'Replace PRNG with cryptographic source (os.urandom, /dev/urandom).',
    },
    'insufficient_rounds': {
        'description': 'Insufficient cipher rounds — residual structure in output',
        'indicators': [('autocorrelation', 0, 2.0), ('multi_lag_ac', 0, 2.0), ('spectral', 1, 2.0)],
        'remediation': 'Use full round count for the cipher. Do not reduce rounds for performance.',
    },
    'ecb_mode': {
        'description': 'ECB mode — identical plaintext blocks produce identical ciphertext',
        'indicators': [('block_repetition', 1, 5.0), ('compression', 1, 5.0)],
        'remediation': 'Use authenticated encryption (GCM, ChaCha20-Poly1305) or at minimum CBC/CTR.',
    },
    'biased_key_schedule': {
        'description': 'Biased key schedule — output byte distribution is non-uniform',
        'indicators': [('byte_frequency', 1, 3.0), ('byte_skewness', 0, 2.0), ('byte_kurtosis', 0, 2.0)],
        'remediation': 'Verify key schedule implementation. Check for weak key classes.',
    },
    'linear_structure': {
        'description': 'Linear structure — output approximable by linear function',
        'indicators': [('linear_complexity', -1, 2.0), ('matrix_rank', 1, 2.0)],
        'remediation': 'Cipher has insufficient nonlinearity. May indicate broken S-box or LFSR leak.',
    },
}


def diagnose(profile):
    """Automated weakness diagnosis from a Z-score profile.

    Maps the profile to known weakness patterns and returns diagnoses
    with confidence levels and remediation advice.

    Args:
        profile: ndarray of shape (N_STRATEGIES,)

    Returns:
        list of dicts, each with 'weakness', 'confidence', 'description',
        'remediation', 'matching_axes'
    """
    names = STRATEGY_NAMES if len(profile) == N_STRATEGIES else CRYPTO_STRATEGY_NAMES
    name_to_idx = {n: i for i, n in enumerate(names)}

    diagnoses = []
    for weakness_name, sig in _WEAKNESS_SIGNATURES.items():
        matching = []
        for strat_name, expected_sign, min_z in sig['indicators']:
            if strat_name not in name_to_idx:
                continue
            idx = name_to_idx[strat_name]
            z = float(profile[idx])
            # Sign check: 0 means any direction, 1 means positive, -1 means negative
            if expected_sign == 0:
                if abs(z) >= min_z:
                    matching.append((strat_name, z))
            elif expected_sign > 0:
                if z >= min_z:
                    matching.append((strat_name, z))
            else:
                if z <= -min_z:
                    matching.append((strat_name, z))

        if len(matching) >= 1:
            # Confidence = fraction of indicators that fired × max Z
            frac = len(matching) / len(sig['indicators'])
            max_z = max(abs(z) for _, z in matching)
            confidence = min(frac * min(max_z / 3.0, 1.0), 1.0)

            diagnoses.append({
                'weakness': weakness_name,
                'confidence': confidence,
                'description': sig['description'],
                'remediation': sig['remediation'],
                'matching_axes': matching,
            })

    # Sort by confidence descending
    diagnoses.sort(key=lambda d: d['confidence'], reverse=True)
    return diagnoses


# ═══════════════════════════════════════════════════════════════
# BOOTSTRAP CI
# ═══════════════════════════════════════════════════════════════

def compute_casi_with_ci(keys, n_bootstrap=100, ci_level=0.95, rng=None):
    """Compute V2 CASI with bootstrap confidence interval.

    Uses BLOCK bootstrap to preserve key ordering (important for temporal
    strategies and seq_correlation). Standard resampling would create
    duplicate adjacent keys, artificially triggering block_repetition
    and seq_correlation.

    Args:
        keys: np.ndarray of shape (n_keys, key_size)
        n_bootstrap: number of bootstrap resamples
        ci_level: confidence level (default 0.95)
        rng: optional RNG

    Returns:
        dict with 'point_estimate', 'mean', 'median', 'std',
             'ci_lower', 'ci_upper', 'profile', 'scores'
    """
    if rng is None:
        rng = np.random.default_rng(42)

    n_keys = keys.shape[0]

    # Point estimate
    profile = compute_profile(keys, rng=np.random.default_rng(42))
    point = float(np.sqrt(np.sum(profile ** 2)))

    # Random half-split bootstrap: take random 50% of keys (without
    # replacement), preserving original ordering. This avoids duplicate
    # keys (block_repetition artifact) and preserves temporal structure.
    half_n = n_keys // 2
    scores = np.zeros(n_bootstrap)
    boot_rng = np.random.default_rng(42)
    for i in range(n_bootstrap):
        idx = np.sort(boot_rng.choice(n_keys, size=half_n, replace=False))
        boot_rng_i = np.random.default_rng(boot_rng.integers(0, 2**32))
        z = compute_profile(keys[idx], rng=boot_rng_i)
        scores[i] = float(np.sqrt(np.sum(z ** 2)))

    alpha = 1.0 - ci_level
    return {
        'point_estimate': point,
        'mean': float(np.mean(scores)),
        'median': float(np.median(scores)),
        'std': float(np.std(scores)),
        'ci_lower': float(np.percentile(scores, 100 * alpha / 2)),
        'ci_upper': float(np.percentile(scores, 100 * (1 - alpha / 2))),
        'ci_level': ci_level,
        'profile': profile.tolist(),
        'scores': scores.tolist(),
    }


# ═══════════════════════════════════════════════════════════════
# STREAMING ENGINE
# ═══════════════════════════════════════════════════════════════

class LiveCASIv2:
    """Real-time V2 CASI engine with sliding window."""

    def __init__(self, key_size=32, window_keys=10000, update_every=1000):
        self.key_size = key_size
        self.window_keys = window_keys
        self.update_every = update_every
        self.buffer = bytearray()
        self.key_ring = []
        self.keys_total = 0
        self.keys_since_update = 0
        self.current_profile = None
        self.current_casi = None
        self.history = []
        self.start_time = time.time()
        self.rng = np.random.default_rng()

    def feed(self, data):
        """Feed raw bytes. Returns True if CASI was recomputed."""
        self.buffer.extend(data)
        new_keys = len(self.buffer) // self.key_size
        if new_keys == 0:
            return False

        used = new_keys * self.key_size
        key_data = np.frombuffer(bytes(self.buffer[:used]), dtype=np.uint8)
        self.key_ring.append(key_data.reshape(-1, self.key_size))
        self.keys_total += new_keys
        self.keys_since_update += new_keys
        self.buffer = bytearray(self.buffer[used:])

        # Trim to window
        total_stored = sum(k.shape[0] for k in self.key_ring)
        while total_stored > self.window_keys and len(self.key_ring) > 1:
            total_stored -= self.key_ring[0].shape[0]
            self.key_ring.pop(0)

        if self.keys_since_update >= self.update_every:
            self._update()
            return True
        return False

    def force_update(self):
        """Force recomputation of CASI."""
        if self.keys_total >= 100:
            self._update()

    def _update(self):
        self.keys_since_update = 0
        if not self.key_ring:
            return
        all_keys = np.vstack(self.key_ring)
        if all_keys.shape[0] > self.window_keys:
            all_keys = all_keys[-self.window_keys:]

        self.current_profile = compute_profile(all_keys, rng=self.rng)
        self.current_casi = float(np.sqrt(np.sum(self.current_profile ** 2)))
        self.history.append({
            'time': self.elapsed(),
            'casi': self.current_casi,
            'keys': self.keys_total,
            'profile': self.current_profile.tolist(),
        })

    def elapsed(self):
        return time.time() - self.start_time

    def rate(self):
        e = self.elapsed()
        return self.keys_total / e if e > 0 else 0


# ═══════════════════════════════════════════════════════════════
# DISPLAY HELPERS
# ═══════════════════════════════════════════════════════════════

def casi_verdict(casi, n_keys=5000):
    """Human-readable verdict for V2 CASI score.

    Thresholds are adaptive to sample size because the chi(k) composite
    has higher variance at small N (fewer keys → noisier Z-scores).
    """
    if casi is None:
        return 'Waiting...'

    # Empirical null (24 strategies): N=5000 → mean≈4.62, p95≈5.98
    # Threshold = null p99 (≈1% FPR)
    if n_keys >= 3000:
        threshold = 7.0
    elif n_keys >= 1000:
        threshold = 7.5
    else:
        threshold = 8.0

    if casi < threshold * 0.6:
        return 'SECURE'
    elif casi < threshold:
        return 'Borderline'
    elif casi < threshold * 3:
        return 'WEAK'
    else:
        return 'BROKEN'


def casi_color(casi):
    """ANSI color for V2 CASI score."""
    if casi is None:
        return '\033[2m'
    if casi < 3.0:
        return '\033[92m'  # green
    if casi < 15.0:
        return '\033[93m'  # yellow
    return '\033[91m'  # red

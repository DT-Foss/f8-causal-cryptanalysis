"""live-casiv2: Signed Z-score architecture for real-time cryptographic quality analysis.

V2 replaces live-casi's abs()+ratio normalization with signed Z-scores.
Each of 15 strategies returns a signed float Z-score. The composite CASI
score is ||Z|| = sqrt(sum of Z_i²), with known null distribution chi(k).

Key improvements over V1:
- Direction information: sign tells you WHICH WAY the weakness goes
- Known null distribution: chi(k) instead of empirical ratio
- Cipher family signatures: signed profile differentiates architectures (CF517)
- 3 new temporal strategies from CASI V2 (adj_corr, trend, variance shift)
"""

__version__ = "2.0.0"

from .engine import (
    compute_profile,
    compute_casi,
    compute_casi_with_ci,
    compute_crypto_profile,
    compute_crypto_casi,
    compute_fast_profile,
    compute_fast_casi,
    deep_scan,
    fisher_amplify,
    cross_round_independence,
    cross_round_mi,
    interpret,
    diagnose,
    dominant_axis,
    casi_verdict,
    LiveCASIv2,
    STRATEGY_NAMES,
    CRYPTO_STRATEGY_NAMES,
    IMPL_STRATEGY_NAMES,
    TEMPORAL_STRATEGY_NAMES,
    EFFECTIVE_DF,
)
